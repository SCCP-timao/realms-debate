# Realms Debate

Aplicação Next.js para condução de debate do Realm.

## Executar

```bash
npm install
npm run dev
```

## Estado atual e limitações

A primeira versão contém portal público e painel do apresentador: cronômetro, etapas, seleção de orador, sorteio, moderação de perguntas e enquetes.

**Persistência atual:** `localStorage` do navegador. Isso mantém a sessão no mesmo dispositivo, mas não sincroniza automaticamente o painel do apresentador com celulares do público. Para operação multi-dispositivo, conectar Supabase (PostgreSQL + Realtime + Auth), aplicar políticas RLS e migrar o estado para o servidor antes do uso como sistema oficial.

Os dados iniciais dos candidatos são demonstrativos e devem ser substituídos pelos nomes e partidos reais do Realm.
